var tCel = +prompt('Введите температуру Цельсия: ');
var tFar = (9 / 5) * tCel + 32;
alert('Температура по Фаренгейту: ' + tFar);

var admin;
var name = 'Василий';
admin = name;
console.log(admin);

var result = 1000 + '108';
console.log(result); //происходит конкетинация и получается тип строка